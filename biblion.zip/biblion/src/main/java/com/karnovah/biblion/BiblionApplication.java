package com.karnovah.biblion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiblionApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiblionApplication.class, args);
	}

}
